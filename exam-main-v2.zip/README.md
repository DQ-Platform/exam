# Dqplatforms
